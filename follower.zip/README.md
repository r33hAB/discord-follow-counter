Can be run in railway, add Key: DISCORD_BOT_TOKEN

Value: well yeah, the discord token. make sure to also update the channel ids to fit your discord server. 
